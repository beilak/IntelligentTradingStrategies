"""Signal chromosome alphabet."""
