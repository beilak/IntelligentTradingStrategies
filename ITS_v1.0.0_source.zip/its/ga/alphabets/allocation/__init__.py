"""Allocation chromosome alphabet."""
