"""Pre-selection chromosome alphabet."""
