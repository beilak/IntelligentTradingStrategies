"""Core strategy building blocks."""
