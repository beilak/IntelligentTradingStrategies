"""GA backend service."""
